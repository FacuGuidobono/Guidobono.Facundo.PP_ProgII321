/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @author facun
 */
public class Constructor extends Superviviente implements Asignable, Capacitable {

    private final int habilidadTecnica;

    public Constructor(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int habilidadTecnica) {
        super(codigo, nombre, nivel, disponible);
        super.validarMayoraCero(habilidadTecnica);
        this.habilidadTecnica = habilidadTecnica;
    }
    
    
    public int mostrarHabilidadTecnica(){
        return habilidadTecnica;
    }
    
    @Override
    protected int calcularAptitud() {
        return habilidadTecnica * 3;
    }

    @Override
    public String asignarTarea(String tarea) {
        super.validarString(tarea);
        if(!estaDisponible()){
            throw new IllegalStateException(" El Constructor " + mostrarNombre() +" se encuentra ocupado");
            
        }
        ocupado();
        
        return "se asigno a " + mostrarNombre() + " la tarea: " + tarea +".";
    }

    @Override
    public String capacitar() {
        return "se capacito a " + mostrarNombre() + " (" + mostrarCodigo()+")." ;
    }

    @Override
    public String toString() {
        return "Constructor [" + super.datosSuperviviente() + ", habilidadTecnica=" + habilidadTecnica + ']';
    }

    
    
}
