/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

import java.util.List;

/**
 *
 * @author facun
 */
public class GuidobonoFacundoPPProgII321Q2 {

    public static void main(String[] args) {
        
        Refugio refugio = new Refugio("Horizonte");

        
        try{
            refugio.agregarSuperviviente(new Explorador(
                    "EXP-101", "Ada", NivelExperiencia.EXPERTO, true, 30));

            refugio.agregarSuperviviente(new Medico(
                    "MED-220", "Bruno", NivelExperiencia.INTERMEDIO, true, 45));

            refugio.agregarSuperviviente(new Constructor(
                    "CON-330", "Carla", NivelExperiencia.EXPERTO, true, 25));

            refugio.agregarSuperviviente(new Explorador(
                    "EXP-404", "Diego", NivelExperiencia.NOVATO, true, 18));

            refugio.agregarSuperviviente(new Medico(
                    "EXP-101", "Ada", NivelExperiencia.NOVATO, true, 12));
        }   
        catch(SupervivienteDuplicadoException ex){
                    System.out.println(ex.getMessage());
                }
        
        System.out.println("Supervivientes registrados:");
        mostrarSupervivientes(refugio.obtenerSupervivientes());
        System.out.println("\nAptitudes:");
        mostrarAptitudes(refugio.obtenerSupervivientes());
        System.out.println("\nAsignacion de tareas:");
        asignarTareas(refugio.obtenerSupervivientes());
        System.out.println("\nCapacitaciones:");
        capacitarSupervivientes(refugio.obtenerSupervivientes());
        System.out.println("\nDisponibles con aptitud >= 50:");
        mostrarSupervivientes(refugio.obtenerDisponiblesConAptitudMinima(50));
        System.out.println("\nSupervivientes EXPERTO:");
        mostrarSupervivientes(refugio.filtrarPorNivel(NivelExperiencia.EXPERTO));
    }

    private static void mostrarSupervivientes(List<Superviviente> lista) {
        
        for( Superviviente s: lista){
            System.out.println(s);
        }
        
    }

    private static void mostrarAptitudes(List<Superviviente> lista) {
        
        for( Superviviente s: lista){
            System.out.println(s.mostrarNombre() + ": " + s.mostrarAptitud());
        }

    }
    
    
    private static void asignarTareas(List<Superviviente> lista) {
        
        
        for( Superviviente s: lista){
            if(s instanceof Asignable asignable){
                
                
                System.out.println(asignable.asignarTarea("Mision de Apoyo"));
            
            }
            else{
            
                System.out.println(s.mostrarNombre() + " no puede recibir tareas.");
            };
        }

    }
 
    private static void capacitarSupervivientes(List<Superviviente> lista) {
        
        for( Superviviente s: lista){
            if(s instanceof Capacitable capacitable){
                
                System.out.println(capacitable.capacitar());
            
            }
            else{
            
                System.out.println(s.mostrarNombre() + " no puede capacitar.");
            };
        }
        
        
    }

    

}//
