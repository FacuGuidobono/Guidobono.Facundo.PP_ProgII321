/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author facun
 */
public class Refugio {
    
    
    private final String nombre;
    private final List<Superviviente> supervivientes;

    public Refugio(String nombre) {
        verificarNoNuloNiEnBlanco(nombre);
        this.nombre = nombre;
        supervivientes = new ArrayList<>();
    }
    
    
    
    
    private void verificarNoNuloNiEnBlanco(String s){
            
        if( s == null || s.isBlank()){
        
            throw new IllegalArgumentException("no puede ser un valor nulo ni estar en blanco");
        }
   
    
    }
    
    
    public void agregarSuperviviente(Superviviente s) throws SupervivienteDuplicadoException{
        
        if(s==null){
             throw new IllegalArgumentException("superviviente no puede ser null.");
        }
        
        if (supervivientes.contains(s)){
            String msg = "No se puedo registrar: Ya existe un superviviente con codigo " + s.mostrarCodigo() + " y nombre " + s.mostrarNombre() + ".";
                throw new SupervivienteDuplicadoException(msg);
        }
        supervivientes.add(s);
        
    }
    
    
   
    
    /**
     * 
     * @return  retorna una copia de la lista de supervivientes del refugio.
     */
    public List<Superviviente> obtenerSupervivientes(){
    
        return new ArrayList<>(supervivientes);
    }
    
    
    
    /**
     * 
     * @param aptitud
     * @return  retorna una lista de supervivientes del refugio.que estan disponibles filtrados por valor de aptitud minima que deben tener
     */  
    
    
     public List<Superviviente> obtenerDisponiblesConAptitudMinima(int aptitud){
         
         List<Superviviente> aptminima = new ArrayList<>();
         if (aptitud < 0){
             throw new IllegalArgumentException("la aptitud no puede ser nula");                        
         }
         
         for (Superviviente s : supervivientes){
             if (s.mostrarAptitud() >= aptitud && s.estaDisponible()){
                 aptminima.add(s);
                }
             
         }
             
         return aptminima; 

     
            }
     
     
     /**
     * 
     * @param nivel 
     * @return  retorna una lista de supervivientes del refugio filtrados por un nivel de experiencia elegido.
     */  
    
     public List<Superviviente> filtrarPorNivel(NivelExperiencia nivel){
         
         List<Superviviente> nivelmin = new ArrayList<>();
         
         
         for (Superviviente s : supervivientes){
             if (s.mostrarNivel() == NivelExperiencia.EXPERTO){
                 nivelmin.add(s);
             }
     }
     
         return nivelmin;
     
     }

     
     
     
     
     

     
     
    @Override
    public String toString() {
        return "Refugio{" + "nombre=" + nombre + ", supervivientes=" + supervivientes + '}';
    }
     
     
    
    
    
}//Refugio
