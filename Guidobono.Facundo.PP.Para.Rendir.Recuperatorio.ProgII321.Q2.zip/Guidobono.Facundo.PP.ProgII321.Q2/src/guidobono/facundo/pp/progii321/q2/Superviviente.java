/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

import java.util.Objects;

/**
 *
 * @author facun     
 * 
 *
 */
public abstract class Superviviente {
    
    private final String codigo;
    private final String nombre;
    private final NivelExperiencia nivel;
    private boolean disponible;
   

    public Superviviente(String codigo, String nombre, NivelExperiencia nivel, boolean disponible) {
        verificarNoNuloNiEnBlanco(codigo);
        verificarNoNuloNiEnBlanco(nombre);
        
        this.codigo = codigo;
        this.nombre = nombre;
        this.nivel = nivel;
        this.disponible = disponible;
      
    }

  
    
    private void verificarNoNuloNiEnBlanco(String s){
            
        if( s == null || s.isBlank()){
        
            throw new IllegalArgumentException("no puede ser un valor nulo ni estar en blanco");
        }
   
    
    }
    
    protected void validarMayoraCero(int valor){
            
        if( valor < 0){
            throw new IllegalArgumentException("permitido solo valores positivos");
        }
    
    }
    
    // reutilizo el metodo, para la subclases ya que no permite protected en verificarNoNuloNiEnBlanco() al usarlo en el constructor.
    protected void validarString(String s){
        verificarNoNuloNiEnBlanco(s);
    
    }
    
    
    /**
     * @return el valor de aptitud que calcula cada especialidad 
     */
    protected abstract int calcularAptitud();
  
   
    public String mostrarNombre(){
            return nombre;
    }
    
    
    public String mostrarCodigo(){
        return codigo;
    };
    
    
    public int mostrarAptitud(){
        return calcularAptitud();
    }
    
    
    public NivelExperiencia mostrarNivel(){
        return nivel;
    }
    
    
    public boolean estaDisponible(){
            return disponible;
    }
    
    /**
     * cambia el estado de disponibilidad.
     */
    protected final void ocupado(){
        disponible = false;
    }
    
    
    
    
    
    @Override
    public int hashCode() {
        return Objects.hash(codigo,nombre);
    }

    @Override
    public boolean equals(Object o) {
        
        if(this == o){
            return true;
        }
        
        if (o==null|| !(o instanceof Superviviente s)){
            return false;
        }
       
        return codigo.equals(s.codigo) && nombre.equals( s.nombre); 
        
    }

    // retorna datos de interes en comun para las subclases.
    public String datosSuperviviente(){
        return  "codigo=" + codigo + ", nombre=" + nombre + ", nivel=" + nivel + ", disponible=" + disponible ;
    }
    
    
    
    
}//superviviente
