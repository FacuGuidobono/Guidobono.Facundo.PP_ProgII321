/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @author facun
 */
public class Medico extends Superviviente implements Capacitable{
    
    
    private final int conocimiento;
    
    public Medico(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int conocimiento) {
        super(codigo, nombre, nivel, disponible);
        super.validarMayoraCero(conocimiento);
        this.conocimiento =  conocimiento;
    }

   
    
    @Override
    protected int calcularAptitud() {
       return conocimiento + 10;
    }

  
    @Override
    public String capacitarse(){
        return "se capacito a " + mostrarNombre() + " (" + mostrarCodigo()+")." ;
    };

    @Override
    public String toString() {
        return "Medico [" + super.datosSuperviviente() + ", conocimiento=" + conocimiento +  ']';
    }
    
    
    
    
    
    
}//Medico
