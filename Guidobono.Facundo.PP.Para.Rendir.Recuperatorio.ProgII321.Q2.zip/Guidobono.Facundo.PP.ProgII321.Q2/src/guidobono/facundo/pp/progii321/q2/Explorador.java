/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @author facun
 */
public class Explorador extends Superviviente implements Asignable{
    
    private final int resistencia;
    
    public Explorador(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int resistencia) {
        super(codigo, nombre, nivel, disponible);
        super.validarMayoraCero(resistencia);
        this.resistencia = resistencia;
    }

    
    
    public int mostrarResistencia(){
            return resistencia;
    }
    
    @Override
    protected int calcularAptitud() {
        return resistencia * 2 ;
    }

    @Override
    public String asignarTarea(String tarea) {
        
        super.validarString(tarea);
        if(!estaDisponible()){
            throw new IllegalStateException(" El Explorador " + mostrarNombre() +" se encuentra ocupado");
            
        }
        ocupado();
        
        return "se asigno a " + mostrarNombre() + " la tarea: " + tarea +".";
     
    }

    @Override
    public String toString() {
        return "Explorador [" + super.datosSuperviviente() + ", resistencia=" + resistencia +  ']';
    
    }
   
    
}//explorador
