/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @ si el superviviente ya existe en el refugio se lanza la exeption.
 */
public class SupervivienteDuplicadoException extends Exception {
    
    private static final String MENSAJE = "YA EXISTE ESE SUPERVIVIENTE EN EL REFUGIO";

    public SupervivienteDuplicadoException() {
        this(MENSAJE);
    }
    
    
    public SupervivienteDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
    
}
