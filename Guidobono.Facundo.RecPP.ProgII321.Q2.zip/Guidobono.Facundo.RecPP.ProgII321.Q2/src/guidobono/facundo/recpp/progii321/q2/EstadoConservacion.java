/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

/**
 *
 * @author facun
 */
public enum EstadoConservacion {
    BUENO,
    REGULAR,
    DELICADO;
    
}
