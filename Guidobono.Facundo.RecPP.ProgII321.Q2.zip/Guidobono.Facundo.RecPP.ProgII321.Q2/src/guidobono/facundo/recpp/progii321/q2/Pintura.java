/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

/**
 *
 * @author facun
 */
public class Pintura extends Obra implements Restaurable,Exhibible {
    private final int superficieCm2;

    public Pintura(String codigo, String autor, EstadoConservacion estado, int superficieCm2 ) {
        super(codigo, autor, estado);
        super.validarMayoraCero(superficieCm2, "el valor de superficie debe ser mayor a cero");
        this.superficieCm2 = superficieCm2;
    }

    
    
    public int mostrarSupercieCm2(){
        return superficieCm2;
    }
    
    @Override
    public int costoMensual() {
        return 100 + superficieCm2/10;
    }

    @Override
    public String restaurar() {
        return "Plan de restauracion de pintura: " + super.mostrarCodigo();
    }

    @Override
    public String exhibir() {
        return "Exhibicion de pintura preparada: " + super.mostrarCodigo();
    }
    
    @Override
    public String toString() {
        return "pintura [" + super.datosDeLaObra() + ", superficieCm2=" + mostrarSupercieCm2() + ", costo=" + mostrarCosto() + ']';
    }
    
}
