/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

/**
 * 
 * @author facun
 * si la obra de arte que se quiere agregar al museo ya existe se lanza la excepcion
 * puede pasarse un mensaje personalizado o usar el msg por defecto.
 */
public class ObraDuplicadaException extends Exception{
    
    private static final String MENSAJE = "YA EXISTE ESA OBRA EN EL MUSEO";
    
    public ObraDuplicadaException(){
        this(MENSAJE);
    }
    
    public ObraDuplicadaException(String mensaje){
        super(mensaje);
    }
    
}
