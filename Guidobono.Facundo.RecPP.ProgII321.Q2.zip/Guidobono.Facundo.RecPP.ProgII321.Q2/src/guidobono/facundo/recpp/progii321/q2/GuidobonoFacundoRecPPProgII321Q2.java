/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

import java.util.List;

/**
 *
 * @author facun
 */
public class GuidobonoFacundoRecPPProgII321Q2 {

    public static void main(String[] args) {
        
        Museo museo = new Museo("Museo Aurora");
        
        try{
            

            museo.agregarObra(new Pintura("OB-101", "L. Vega",
                    EstadoConservacion.DELICADO, 500));

            museo.agregarObra(new Escultura("OB-102", "M. Solis",
                    EstadoConservacion.REGULAR, 12));
            museo.agregarObra(new DocumentoAntiguo("OB-103", "Anonimo",
                    EstadoConservacion.DELICADO, 300));
            museo.agregarObra(new Pintura("OB-104", "M. Solis",
                    EstadoConservacion.BUENO, 700));
            museo.agregarObra(new Escultura("OB-101", "L. Vega",
                    EstadoConservacion.BUENO, 5));
            
        }catch(ObraDuplicadaException e){
                System.out.println(e.getMessage());
                }
        
        
        System.out.println("Obras registradas:");
        mostrarObras(museo.obtenerObras());
        System.out.println("\nPlanes de restauracion:");
        mostrarRestauraciones(museo.obtenerObras());
        System.out.println("\nPreparacion de exhibiciones:");
        mostrarExhibiciones(museo.obtenerObras());
        System.out.println("\nObras en estado DELICADO:");
        mostrarObras(museo.filtrarPorEstado(EstadoConservacion.DELICADO));
        System.out.println("\nObra de mayor costo:");
        mostrarMayorCosto(museo.obtenerObraDeMayorCosto());
    }

    private static void mostrarObras(List<Obra> obras) {

            for(Obra o : obras){
                    System.out.println(o);
            }


    }

    private static void mostrarRestauraciones(List<Obra> obras) {
       
        for(Obra o : obras){
            
            if(o instanceof Restaurable restaurarable){
                    System.out.println(restaurarable.restaurar());
            }
            else{
                System.out.println("La obra " + o.mostrarCodigo() + " no admite restauracion.");
            }
        }
    }

    private static void mostrarExhibiciones(List<Obra> obras) {
             
        for(Obra o : obras){
            
            if(o instanceof Exhibible exhibible){
                    System.out.println(exhibible.exhibir());
            }
            else{
                System.out.println("La obra " + o.mostrarCodigo() + " no admite exhibicion.");
            }
        }
    }

    private static void mostrarMayorCosto(Obra obra) {
// Completar: contemplar una coleccion vacia
    }

}
