/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author facun
 */
public class Museo {
    private final String nombre;
    private final List<Obra> obras;

    
    public Museo(String nombre) {
        verificarNoNuloNiEnBlanco(nombre, "El nombre no puede ser null ni estar en blanco");
        this.nombre = nombre;
        this.obras = new ArrayList<>();
        
    }

     /**
     * 
     * @param s String a evaluar
     * @param mensaje mensaje personalizado
     * verifica que el String ingresado sea valido.
     */
    private void verificarNoNuloNiEnBlanco(String s, String mensaje){
    
        if(s==null|| s.isBlank()){
        
                throw new IllegalArgumentException(mensaje);
        
        }
    }
    
    
    
    /**
     * 
     * @param o  obra nueva a agregar 
     * @throws ObraDuplicadaException  se lanza si la obra ya esta en el museo.
     */
    public void agregarObra(Obra o) throws ObraDuplicadaException{
        
        if(o == null){
            throw new IllegalArgumentException("La obra no puede ser null");
        }
        
        if(obras.contains(o)){
            String msg = "No se pudo agregar: Ya existe una obra con codigo " +"'"+o.mostrarCodigo() +"'" + " y autor " + "'"+ o.mostrarAutor() +"'" + ".";
            throw new ObraDuplicadaException(msg);
        
        }
        
        obras.add(o);
    
    }

    
    /**
     * 
     * @return una copia de las obras que tiene el museo. 
     */
    public List<Obra> obtenerObras(){
            return new ArrayList<>(obras);
    }
    
    
    /**
     * 
     * @param estadoRequerido
     * @return una lista de obras filtrados por el estado en el que se encuentran
     */
    
    public List<Obra> filtrarPorEstado(EstadoConservacion estadoRequerido){
        
        if(estadoRequerido == null){
            throw new IllegalArgumentException("el estado no puede ser null");
        }
    
        List<Obra> obrasPorEstado = new ArrayList<>();
    
        for(Obra o :obras){
                if(o.mostrarEstado() == estadoRequerido){
                    obrasPorEstado.add(o);
                }
        }
        
        return obrasPorEstado;
    }
    
    
    
    public Obra obtenerObraDeMayorCosto(){
        
        return obras.get(0);  // no llegue a implementar
       
    }
    
   
    
    
    @Override
    public String toString() {
        return "Museo{" + "nombre=" + nombre + ", obras=" + obras + '}';
    }
   
    
    
    
    
    
    
    
    
    
    
    
}
