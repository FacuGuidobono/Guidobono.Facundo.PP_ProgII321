/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

/**
 *
 * @author facun
 */
public class DocumentoAntiguo extends Obra implements Restaurable{
    private final int antiguadadAnios;

    public DocumentoAntiguo(String codigo, String autor, EstadoConservacion estado,int antiguadadAnios) {
        super(codigo, autor, estado);
        super.validarMayoraCero(antiguadadAnios, "La antiguedad del documento tiene que ser mayor a cero");
        this.antiguadadAnios = antiguadadAnios;
    }
    
    
    public int mostrarAntiguedad(){
        return antiguadadAnios;
    
    }
    
     @Override
    public int costoMensual() {
        return 60 + antiguadadAnios/5;
    }
    
    
    @Override
    public String restaurar() {
        return "Plan de restauracion de pintura: " + super.mostrarCodigo();
    }

   
    @Override
    public String toString() {
        return "DocumentoAntiguo [" + super.datosDeLaObra() + ", antiguedadAnios=" + mostrarAntiguedad() + ", costo=" + mostrarCosto() + ']';
    }
    

}
