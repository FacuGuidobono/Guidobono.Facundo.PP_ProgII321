/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;


public class Escultura extends Obra implements Exhibible{
    
    private final int pesoKg;

    public Escultura(String codigo, String autor, EstadoConservacion estado,int pesoKg) {
        super(codigo, autor, estado);
        super.validarMayoraCero(pesoKg,"El peso de la escultura tiene que ser mayor a cero");
        this.pesoKg = pesoKg;
    }
    
    
    public int mostrarPeso(){
        return pesoKg;
    }
    
    @Override
    public int costoMensual() {
        return 80 + pesoKg * 15;
    }
    
    
    @Override
    public String exhibir() {
        return "Exhibicion de pintura preparada: " + super.mostrarCodigo();
    }

    @Override
    public String toString() {
        return "Escultura [" + super.datosDeLaObra() + ", pesoKg=" + mostrarPeso() + ", costo=" + mostrarCosto() + ']';
    }

    
    
    
    
    
    
}
