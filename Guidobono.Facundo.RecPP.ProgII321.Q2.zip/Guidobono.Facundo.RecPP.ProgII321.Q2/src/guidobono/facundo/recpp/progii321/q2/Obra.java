/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321.q2;

import java.util.Objects;

/**
 *
 * @author facun
 */
public abstract class Obra {
    
    private final String codigo;
    private String autor;
    private EstadoConservacion estado;

    public Obra(String codigo, String autor, EstadoConservacion estado) {
        verificarNoNuloNiEnBlanco(codigo,"El codigo no puede ser nulo, ni estar en blanco");
        verificarNoNuloNiEnBlanco(autor,"El autor no puede ser nulo, ni estar en blanco");
        this.codigo = codigo;
        this.autor = autor;
        this.estado = estado;
    }
    
    
    /**
     * 
     * @param s String a evaluar
     * @param mensaje mensaje personalizado
     * verifica que el String ingresado sea valido.
     */
    private void verificarNoNuloNiEnBlanco(String s, String mensaje){
    
        if(s==null|| s.isBlank()){
        
                throw new IllegalArgumentException(mensaje);
        
        }
    }
    
    public void validarMayoraCero(int valor, String mensaje){
    
            if(valor<0){
                    throw new IllegalArgumentException(mensaje);
            }
    
    }
    
    
    
    /**
     * 
     * @return valor del costo que calcula cada Obra 
     */
    public abstract int costoMensual();
    
    
    
    public EstadoConservacion mostrarEstado(){
            
       return estado;
            
    }
    
    public int mostrarCosto(){
        return costoMensual(); 

    }
    
    public String mostrarCodigo(){
        
        return codigo;
    }
    
    public String mostrarAutor(){
        return autor;
    }
    
    
    
    

    @Override
    public int hashCode(){      
        return Objects.hash(codigo,autor);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null||!(obj instanceof Obra o)) {
            return false;
     
        }
        return codigo.equals(o.codigo) && autor.equals(o.autor);
    }
    
    
    
    
    public String datosDeLaObra(){
               return "codigo=" + codigo + ", autor=" + autor + ", estado=" + estado;
    }

    
   
    
    
    
    
    
}//Obra
