/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author facun
 */
public class Refugio {
    
    
    private String nombre;
    private List<Superviviente> supervivientes;

    public Refugio(String nombre) {
        verificarNoNuloNiEnBlanco(nombre);
        this.nombre = nombre;
        supervivientes = new ArrayList<>();
    }
    
    
    
    
    private void verificarNoNuloNiEnBlanco(String s){
            
        if( s == null || s.isBlank()){
        
            throw new IllegalArgumentException("no puede ser un valor nulo ni estar en blanco");
        }
   
    
    }
    
    
    public void agregarSuperviviente(Superviviente s) throws SupervivienteDuplicadoException{
        
        if(s==null){
             throw new IllegalArgumentException("no se admite este tipo de superviviente");
        }
        
        if (supervivientes.contains(s)){
                throw new SupervivienteDuplicadoException();
        }
        supervivientes.add(s);
        
    }
    
    
   
    
    /**
     * 
     * @return  retorna una copia de la lista de supervivientes del refugio.
     */
    public List<Superviviente> obtenerSupervivientes(){
    
        return new ArrayList<>(supervivientes);
    }
    
    
     public List<Superviviente> obtenerDisponiblesConAptitudMinima(int aptitud){
         
         List<Superviviente> aptminima = new ArrayList<>();
         if (aptitud < 0){
             throw new IllegalArgumentException("la aptitud no puede ser nula");                        
         }
         
         for (Superviviente s : supervivientes){
             if (s.obtenerAptitud() >= aptitud){
                 aptminima.add(s);
             }
             
         
     
         return aptminima; 

     
     }
    
     public List<Superviviente> filtrarPorNivel(NivelExperiencia nivel){
         
         List<Superviviente> nivelmin = new ArrayList<>();
         
         
         for (Superviviente s : supervivientes){
             if (s.obtenerNivel() == nivel){
                 nivelmin.add(s);
             }
     }
     
         return nivelmin;
     
     }
    
    
}
