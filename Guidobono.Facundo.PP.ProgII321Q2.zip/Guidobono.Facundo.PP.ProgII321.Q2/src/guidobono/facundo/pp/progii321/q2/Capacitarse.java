/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @author facun
 */
public interface Capacitarse {
    abstract void capacitarse();
}
