/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

import java.util.Objects;

/**
 *
 * @author facun     
 * 
 *
 */
public abstract class Superviviente {
    
    private String codigo;
    private String nombre;
    private NivelExperiencia nivel;
    private boolean disponible;
    private int aptitud;

    public Superviviente(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int aptitud) {
        verificarNoNuloNiEnBlanco(codigo);
        verificarNoNuloNiEnBlanco(nombre);
        validarAptitud(aptitud);
        
        this.codigo = codigo;
        this.nombre = nombre;
        this.nivel = nivel;
        this.disponible = disponible;
        this.aptitud = aptitud;
    }

  
    
    private void validarAptitud(int a){
    
            if( a < 0){
            throw new IllegalArgumentException("La aptitud no puede ser negativa");
        }
   
    }
    
    
    private void verificarNoNuloNiEnBlanco(String s){
            
        if( s == null || s.isBlank()){
        
            throw new IllegalArgumentException("no puede ser un valor nulo ni estar en blanco");
        }
   
    
    }
    
    
    
    
    protected abstract int calcularAptitud();

    
    public int obtenerAptitud(){
        return aptitud;
    }
    
    
    public NivelExperiencia obtenerNivel(){
        return nivel;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(codigo,nombre);
    }

    @Override
    public boolean equals(Object o) {
        
        if (o==null|| !(o instanceof Superviviente s)){
            return false;
        }
       
        return codigo.equals(s.codigo) && nombre.equals( s.nombre); 
    }
    
    
    
    
}
