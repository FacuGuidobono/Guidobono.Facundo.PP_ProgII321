/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @author facun
 */
public class Constructor extends Superviviente implements Tareas, Capacitarse{ 

    public Constructor(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int aptitud) {
        super(codigo, nombre, nivel, disponible, aptitud);
    }

  
    
    @Override
     protected int calcularAptitud() {
       return this.obtenerAptitud() * 3;
    }



    @Override
    public void realizarTarea() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void capacitarse() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
