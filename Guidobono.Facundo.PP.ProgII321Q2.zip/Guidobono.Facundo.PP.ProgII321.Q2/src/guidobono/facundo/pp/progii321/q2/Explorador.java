/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @author facun
 */
public class Explorador extends Superviviente implements Tareas{

    public Explorador(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int aptitud) {
        super(codigo, nombre, nivel, disponible, aptitud);
    }

  
    
    @Override
    protected int calcularAptitud() {
        return this.obtenerAptitud()*2 ;
    }

    @Override
    public void realizarTarea() {
       return 
    }
    
    
    
    
    
    
}
