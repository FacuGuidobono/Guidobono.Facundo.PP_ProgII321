/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321.q2;

/**
 *
 * @ avisa si el superviviente ya esta en la lista
 */
public class SupervivienteDuplicadoException extends Exception {
    
    private static final String MENSAJE = "YA EXISTE ESE SUPERVIVIENTE";

    public SupervivienteDuplicadoException() {
        this(MENSAJE);
    }
    
    
    public SupervivienteDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
    
}
